// Author: Suresh Sathyanarayana
// Date: 09/01/2020
// The goal of this program is to find the longest word in a file and then to transpose the longest word.

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.*; 


public class FindLongestWordAndTranspose {

	public static String longestWord = "";
	public static String transposedWord = "";
	public static String fileName = "";
	public String currentWord = "";

	// This is the default constructor
	public FindLongestWordAndTranspose() {
	}

	// In this method the user is asked to input a filename
	public String inputFileName() {
	        Scanner input = new Scanner(System.in);

		System.out.print("Enter File Name: ");
        	String fileName = input.next();
		
		return fileName;
	}

	// In this method first the file name is checked to it exists. 
        // If file name does exist, then gracefully exit.
        // If the file does exist, then check to see if it has a .txt extension.
        // If it does not have a .txt extension, then gracefully exit.
        // Also check to see if the file is empty....
        // If all the above criteria are met, file is scanned for the longest word.
	public String getLongestWord() throws FileNotFoundException {
		try {
			// First check to see if the file itself exists
    			Scanner scan = new Scanner(new File(fileName));
	
			// Check for file extension .txt	
			File file = new File(fileName);	
			String getFileName = file.getName();
			String extension = getFileName.substring(getFileName.lastIndexOf(".")+1);
			if(extension.compareTo("txt") != 0){
                                System.out.println("The file has to have a .txt extension....");
                                System.exit(0);
			}

			// All the above criteria have been met....proceed with the scanning of the file
    			while (scan.hasNext()) {
        			currentWord = scan.next();
        			if (currentWord.length() > longestWord.length()) {
            				longestWord = currentWord;
       				} 
    			}
			// If the file is empty, then print this
			if(longestWord == "") {
				System.out.println("The file is empty and has no words in it....");
				System.exit(0);
			}
		}
		catch(FileNotFoundException f) {
			System.out.println("The file does not exist...Please input a valid filename");
			System.exit(0);
		}
            	
		return longestWord;
        }

	// In this method the longest word is transposed
	public String getTransposedWord() {
        	StringBuffer stringBuffer1 = new StringBuffer(longestWord); 
        	StringBuffer stringBuffer2 = new StringBuffer(""); 

		stringBuffer2 = stringBuffer1.reverse();
		transposedWord = stringBuffer2.toString();
		return transposedWord; 
	} 

	public static void main(String [ ] args) throws FileNotFoundException {
		FindLongestWordAndTranspose getFileName = new FindLongestWordAndTranspose();
		FindLongestWordAndTranspose findLongestWord = new FindLongestWordAndTranspose();
		FindLongestWordAndTranspose transposeWord = new FindLongestWordAndTranspose();
		fileName = getFileName.inputFileName();
		longestWord = findLongestWord.getLongestWord();
		transposedWord = transposeWord.getTransposedWord();

		System.out.println("");
		System.out.println("");
		System.out.println("The longest word is: "+longestWord);
		System.out.println("");
		System.out.println("");
		System.out.println("The transposed word is: "+transposedWord);
		System.out.println("");
		System.out.println("");
 	}

}
